<?php

return [
    "name" => "Манго",
    "fname" => "Манго2",
    "description" => "Система телефонии MANGO",
    "transfer" => "Перенаправлять при вх. звонке на ответственного",
    "createRelationship" => "Создавать контакт",
    "createDeals" => "Добавить звонок в последнюю сделку",
    "url" => "Адрес API Виртуальной АТС (call-back)",
    "api_key" => "Уникальный код вашей АТС (из ЛК Mango Office)",
    "api_salt" => "Ключ для создания подписи (из ЛК Mango Office)"
];