# plugin-phone-example
Phone plugin example

Documentation: https://developers.rbs360.ru/razrabotka-plaginov/
