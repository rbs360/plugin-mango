<?php
	
	/** Manifest plugin */
	
	
	return [
    "name" => "mango",
    "description" => "SystemPhone telephone MANGO production",
    "types" => [
	"phone",
    ],
    "vendor" => "RBS360",
    "version" => "1.2",
    "rating" => 5,
    "settings" => [
	"key" => "",
	"salt" => "",
	"url" => "",
	"tranfser",
	"createRelationship",
	"createDeals",
    ]
];